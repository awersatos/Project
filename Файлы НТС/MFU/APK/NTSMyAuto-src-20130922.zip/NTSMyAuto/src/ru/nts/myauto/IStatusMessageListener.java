package ru.nts.myauto;

public interface IStatusMessageListener {
	public void onSignal(String status);
}
